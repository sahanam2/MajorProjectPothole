package com.example.potholedetection

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
